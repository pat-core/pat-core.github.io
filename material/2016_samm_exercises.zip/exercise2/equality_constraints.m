% SAMM 2017, exercise 2: optimal control of a pendulum on a cart with forcing
% by a Variational Integrator discretization (linear interpolation, m.p.-rule)
% 
% author: kathrin.flasskamp@uni-bremen.de
%
% [] = equality_constraints(x)
%
% generates the vector of equality constraints consisting of boundary conditions
% on positions and momenta, and discrete Euler-Lagrange equations
%
% Input:  x vector of optimization variables, assumed to be sorted as
%         [q(1,1), q(1,2),q(2,1),q(2,2),q(3,1),q(3,2), ...., u(1),u(2),...]
%        cf. reshaping commands below
%
% Output: r vector of constraints for which r=0 should hold

  
  function r = equality_constraints (x)
  
      global mp;
      global mc;
      global l;
      global g;
      global dim;
      global dim_u;
      global h;
      global N;
      global x_bound;
      
      q = reshape(x(1:dim*(N+1)),dim,N+1)';
      u = reshape(x(dim*(N+1)+1:end),dim_u,N)';

        
      % Discrete Euler-Lagrange equations, dim*(N-1) equations, stored in matrix
      DEL = zeros(dim,N-1);
      for i=1:N-1
        DEL(:,i) = (D1Ld(q(i+1,:),q(i+2,:))+D2Ld(q(i,:),q(i+1,:))+fplus(u(i))+fminus(u(i+1)))';
      endfor  
        
      r = [ x_bound(:,1)-q(1,:)'; % constraints on initial configurations (2 lines)
            x_bound(:,2)+D1Ld(q(1,:),q(2,:))+fminus(u(1)); % constraints on initial momenta (2 lines)
            reshape(DEL,(N-1)*dim,1); % reshaped DEL equations
            -x_bound(:,4)+D2Ld(q(N,:),q(N+1,:))+fplus(u(N)); % constraints on final momenta (2 lines)
            x_bound(:,3)-q(N+1,:)' % constraints on final configurations (2 lines)
            ];
  endfunction