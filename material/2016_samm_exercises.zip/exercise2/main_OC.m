% SAMM 2017, exercise 2: optimal control of a pendulum on a cart with forcing
% by a Variational Integrator discretization (linear interpolation, m.p.-rule)
% 
% author: kathrin.flasskamp@uni-bremen.de
%
% main file for optimal control of cart-pendulum with force control.
%
% Configuration is q=[x, a] with cart position x, pendulum angle a. See
% definition of optimal control problem (initial & final points, final time,
% discretization) below. Initial guess for configurations is lin. interpolation
% between initial and final point, u is initialized with zero. Alternatively,
% refinements of previous solutions can be used. Solutions are depicted in
% static plots and a video.


% "clean up"
clear all; close all; clc
format long g

% parameter initialization
global mp;
global mc;
global l;
global g;
global dim ;
global dim_u;
global T;
global N;
global h;
global x_bound;

% System
mp=1;
mc=0.5;
l=0.1;
g=9.81;
dim = 2; %state dimension
dim_u = 1; %number of controls

% OCP and discretization
T = 0.5; % final time
q_ini = [0;-pi/2]; 
q_end = [0;pi/2];
v_ini = [0;0];
v_end = [0;0];

N = 50; % N+1 discrete nodes
h = T/N; % resulting step size
t=0:h:T; % time vector


% -----------------
%   Initial guess
% -----------------

% linear interpolation and zero controls:
% Note that we define N+1 nodes for configurations. Since controls are applied
% to intervals, u is N lines only.
%q_guess = linspace(q_ini,q_end,N+1)';
%u_guess = zeros(dim_u*N,1);
%x_guess = [reshape(q_guess',(N+1)*dim,1);u_guess];

% Alternatively, refine previous solution, e.g. for N = 10
% This solution needs to be stored by "save filename t x" beforehand.

%load solution_octave_N10;
%q_N10 = reshape(x_N10(1:dim*(10+1)),dim,10+1)';
%u_N10 = reshape(x_N10(dim*(10+1)+1:end),dim_u,10)';
%q_guess = interp1(t_N10,q_N10,t);
%u_guess = interp1(t_N10,[u_N10;0],t)';
%x_guess = [reshape(q_guess',(N+1)*dim,1);u_guess(1:end-1)];

%load solution_octave_N20;
%num = 20;
%q_N20 = reshape(x_N20(1:dim*(num+1)),dim,num+1)';
%u_N20 = reshape(x_N20(dim*(num+1)+1:end),dim_u,num)';
%q_guess = interp1(t_N20,q_N20,t);
%u_guess = interp1(t_N20,[u_N20;0],t)';
%x_guess = [reshape(q_guess',(N+1)*dim,1);u_guess(1:end-1)];

%load solution_octave_N30;
%num = 30;
%q_N30 = reshape(x_N30(1:dim*(num+1)),dim,num+1)';
%u_N30 = reshape(x_N30(dim*(num+1)+1:end),dim_u,num)';
%q_guess = interp1(t_N30,q_N30,t);
%u_guess = interp1(t_N30,[u_N30;0],t)';
%x_guess = [reshape(q_guess',(N+1)*dim,1);u_guess(1:end-1)];

load solution_octave_N40;
num = 40;
q_N40 = reshape(x_N40(1:dim*(num+1)),dim,num+1)';
u_N40 = reshape(x_N40(dim*(num+1)+1:end),dim_u,num)';
q_guess = interp1(t_N40,q_N40,t);
u_guess = interp1(t_N40,[u_N40;0],t)';
x_guess = [reshape(q_guess',(N+1)*dim,1);u_guess(1:end-1)];


% -----------------
%   Boundary values
% -----------------
% transform inital and final velocity into momenta
p_ini = LegendreTrafo(q_ini,v_ini);
p_end = LegendreTrafo(q_end,v_end);
x_bound = [q_ini,p_ini,q_end,p_end];


% -----------------
%   Box constraints
% -----------------
% lb for lower bound, ub for upper bound. Cf. to sqp function call.
lb_q = reshape([-0.2*ones((N+1),1),-pi*ones((N+1),1)]',(N+1)*dim,1);
lb_u = -50*ones(N*dim_u,1);
lb = [lb_q;lb_u];
ub = -lb;


% -----------------
%   Call of SQP solver
% -----------------

% parameters of algorithm
maxiter = 500;
tol = 1e-4;

tic %start timer
[x, obj, info, iter, nf, lambda] = sqp (x_guess,@cost_function,@equality_constraints,[],lb,ub,maxiter,tol);
toc %stop timer
 
% Display results (info=101 would be ideal, 104 is okay for this example, 103 is
% termination because maximum of iteration steps is reached -> adjust maxiter)
% nf is number of function calls
info
iter
nf

% -----------------
%   Plot results
% -----------------
% static plots
q = reshape(x(1:dim*(N+1)),dim,N+1)';
u = reshape(x(dim*(N+1)+1:end),dim_u,N)';

figure; 
subplot(3,1,1)
hold on
plot(t,q(:,1),'r'); xlabel('time'); ylabel('cart position');
hold on
subplot(3,1,2)
hold on
plot(t,q(:,2),'r'); xlabel('time'); ylabel('angle');
hold on
subplot(3,1,3)
hold on
plot((t(1:end-1)+t(2:end))/2,u,'r'); xlabel('time'); ylabel('control');
hold on

% video
visualization(t,q,u);

