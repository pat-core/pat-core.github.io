% SAMM 2017, exercise 2: optimal control of a pendulum on a cart with forcing
% by a Variational Integrator discretization (linear interpolation, m.p.-rule)
% 
% author: kathrin.flasskamp@uni-bremen.de
%
% TEMPLATE for main file for optimal control of cart-pendulum with force control
%
% Configuration is q=[x, a] with cart position x, pendulum angle a. See
% definition of optimal control problem (initial & final points, final time,
% discretization) below. Initial guess for configurations is lin. interpolation
% between initial and final point, u is initialized with zero. Alternatively,
% refinements of previous solutions can be used. Solutions are depicted in
% static plots and a video.


% "clean up"
clear all; close all; clc
format long g

% parameter initialization
global mp;
global mc;
global l;
global g;
global dim ;
global dim_u;
global T;
global N;
global h;
global x_bound;

% System
mp=1;
mc=0.5;
l=0.1;
g=9.81;
dim = 2; %state dimension
dim_u = 1; %number of controls

% OCP and discretization
T = 0.5; % final time
q_ini = [0;-pi/2]; 
q_end = [0;pi/2];
v_ini = [0;0];
v_end = [0;0];

N = 10; % N+1 discrete nodes
h = T/N; % resulting step size
t=0:h:T; % time vector


% -----------------
%   Initial guess
% -----------------

% linear interpolation and zero controls:
% Note that we define N+1 nodes for configurations. Since controls are applied
% to intervals, u is N lines only.
q_guess = linspace(q_ini,q_end,N+1)';
u_guess = zeros(dim_u*N,1);
x_guess = [reshape(q_guess',(N+1)*dim,1);u_guess];

% Alternatively, refine previous solution, e.g. for N = 10
% This solution needs to be stored by "save filename t x" beforehand.


% -----------------
%   Boundary values
% -----------------

...

x_bound =



% -----------------
%   Box constraints
% -----------------


...

lb = 
ub =


% -----------------
%   Call of SQP solver
% -----------------

% parameters of algorithm
maxiter = 500;
tol = 1e-4;

tic %start timer
[x, obj, info, iter, nf, lambda] = sqp (x_guess,@cost_function,@equality_constraints,[],lb,ub,maxiter,tol);
toc %stop timer
 
% Display results (info=101 would be ideal, 104 is okay for this example, 103 is
% termination because maximum of iteration steps is reached -> adjust maxiter)
% nf is number of function calls
info
iter
nf

% -----------------
%   Plot results
% -----------------
% static plots
q = reshape(x(1:dim*(N+1)),dim,N+1)';
u = reshape(x(dim*(N+1)+1:end),dim_u,N)';

figure; plot(t,q); xlabel('time'); ylabel('configurations');
figure; plot((t(1:end-1)+t(2:end))/2,u,'r'); xlabel('time'); ylabel('control');

% video
visualization(t,q,u);
