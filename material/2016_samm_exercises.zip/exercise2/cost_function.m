% SAMM 2017, exercise 2: optimal control of a pendulum on a cart with forcing
% by a Variational Integrator discretization (linear interpolation, m.p.-rule)
% 
% author: kathrin.flasskamp@uni-bremen.de
%
% [] = cost_function(x)
%
% provides a discrete cost function for optimization, namely control effort
%
% Input:  x vector of optimization variables, assumed to be sorted as
%         [q(1,1), q(1,2),q(2,1),q(2,2),q(3,1),q(3,2), ...., u(1),u(2),...]
%        cf. reshaping commands below
%
% Output: obj scalar value of costs 

function obj = cost_function (x)
     
     global h;
     global N;
     global dim;
     global dim_u;
     
     q = reshape(x(1:dim*(N+1)),dim,N+1)';
     u = reshape(x(dim*(N+1)+1:end),dim_u,N)';
    
     obj=0;
     for i=1:N
        obj=obj+.5*h*u(i)^2;
     endfor
endfunction