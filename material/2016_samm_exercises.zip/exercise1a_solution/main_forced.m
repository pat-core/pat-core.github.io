% SAMM 2017, exercise 1a: simulation of a pendulum on a cart with forcing
% by a Variational Integrator (linear interpolation, m.p.-rule)
% 
% author: dominik.kern@mb.tu-chemnitz.de
%
% generalized coordinates  q=[a, x]    pendulum angle a, cart position x
%
% future work: use dim.less coordinates X=x/l and dim.less time tau=t/h
clear; close all; clc
format long g

%% INIT
% model parameters
mp=1;               % pendulum mass (mathematical pendulum)
mc=0.5;             % cart mass
l=0.1;              % pendulum length (mathematical pendulum)
g=9.81;             % gravitational acceleration
a0=-pi/2;           % initial pendulum angle
at0=0;              % initial angular velocity
x0=0;               % initial cart position
xt0=0;              % initial cart velocity
fh=mp*g/5;          % forcing amplitude related to pendulum weight
T=2*pi/sqrt(g/l);   % period of pendulum only (without cart), for estimating time step and forcing
% derived parameters
m=mp+mc;    
J=mp*l^2;

f=@(tt) [0; fh*sin(2*pi*tt/T)];     % force vector, zero at pendulum, periodic at cart
te=4*T;


% % non-optimal inversion attempts as transition to exercise 2, 
% just playing around..
% tm=2.5; te=2*tm      % half-time
% ae=pi/2;             % alpha end
% a3=-1/6;             % coefficients of polynomial, a3 determines reach-back
% a1=ae/tm-a3*tm^2;    % a1 determined by symmetric graph in 0<t<te
% a=@(tt) a3*(tt-tm).^3+a1*(tt-tm);    % angle as function of time
% at=@(tt)   3*(tt-tm).^2+a1;   % and its time derivatives
% att=@(tt)  6*(tt-tm);
% f=@(tt) [0*tt; ( m*( att(tt).*J./(mp*l*sin(a(tt))) + g.*cot(a(tt))).*(abs(a(tt))>0.05) - mp*l*( att(tt).*sin(a(tt)) + at(tt).^2.*cos(a(tt)) ) ).*(tt<2*tm)];     


% time discretization
h=T/100;
t=0:h:te;
N=length(t)-1;


% Da=a2-a1, Dx=x2-x1, Sa=a2+a1, Sx=x2+x1 for brevity, although this obscures the arguments of Ld([a1,x1],[a2,x2])
D1Ld=@(Da,Dx,Sa,Sx) [ (mp/h)*l*Dx*(sin(Sa/2)-(Da/2)*cos(Sa/2)) - (J/h)*Da - (h/2)*mp*g*l*cos(Sa/2);...
                     -(m/h)*Dx + (mp/h)*l*Da*sin(Sa/2)  ];
D2Ld=@(Da,Dx,Sa,Sx) [-(mp/h)*l*Dx*(sin(Sa/2)+(Da/2)*cos(Sa/2)) + (J/h)*Da - (h/2)*mp*g*l*cos(Sa/2);...
                      (m/h)*Dx - (mp/h)*l*Da*sin(Sa/2) ];
D2D1Ld=@(Da,Dx,Sa,Sx) [ (mp/h)*l*Dx*(Da/4)*sin(Sa/2) - J/h + (h/4)*mp*g*l*sin(Sa/2),...
                        (mp/h)*l*(sin(Sa/2)-(Da/2)*cos(Sa/2));...
                        (mp/h)*l*(sin(Sa/2)+(Da/2)*cos(Sa/2)),...
                       -m/h ];

ieqRES=@(t1,p1,q1,q2) p1 + D1Ld(q2(1)-q1(1),q2(2)-q1(2),q2(1)+q1(1),q2(2)+q1(2)) + (h/2)*f(t1+h/2); % residuum of iteration equation
ieqTAN=@(t1,p1,q1,q2)    D2D1Ld(q2(1)-q1(1),q2(2)-q1(2),q2(1)+q1(1),q2(2)+q1(2));

MassMatrix2x2=@(tt,zz) [J, -mp*l*sin(zz(1));  -mp*l*sin(zz(1)), m];  % for Legendre-Transformation
% conversion generalized velocities to momenta and back
v2p=@(AA,XX,AT,XT) MassMatrix2x2(0, [AA,XX,0,0])*[AT;XT];
p2v=@(AA,XX,PA,PX) MassMatrix2x2(0, [AA,XX,0,0])\[PA;PX];

% N time steps, N+1 time points
q=zeros(N+1,2);   % generalized coordinates
p=zeros(N+1,2);	  % generalized momenta
v=zeros(N+1,2);	  % generalized velocities

%% VI
q1=[a0; x0];
p1=v2p(a0, x0, at0, xt0);
q(1,:)=q1;
p(1,:)=p1;
v(1,:)=[at0; xt0];
q2p=q1+h*[at0; xt0];  % prediction for q2

for n=1:N
    q2=my_fsolve(@(qq) ieqRES(t(n),p1,q1,qq),...
                 @(qq) ieqTAN(t(n),p1,q1,qq),...
                 q2p) ; % solving for q2 with initial guess q2p
    p2=D2Ld(q2(1)-q1(1), q2(2)-q1(2), q2(1)+q1(1), q2(2)+q1(2)) + (h/2)*f(t(n)+h/2); % update equation p_2=D2Ld+fd^+
    q(n+1,:)=q2;
    p(n+1,:)=p2;
    v(n+1,:)=p2v(q2(1), q2(2), p2(1), p2(2));
    q2p=2*q2-q1; % prediction for q2
    q1=q2;
    p1=p2;  
end


%% post-processing

disp(['a(t_e)=',num2str(q(end,1)),' RAD      x(t_e)=',num2str(q(end,2)),' m']);

% verification results 
figure; % figure_init
[hAx,hLine1,hLine2]=plotyy(t, q(:,1), t, q(:,2));
%set(hAx(1),'PlotBoxAspectRatio' , [1 1 0.9]);
%set(hAx(2),'PlotBoxAspectRatio' , [1 1 0.9]);
xlabel('time [s]')
ylabel(hAx(1),'pendulum angle [RAD]') % left y-axis
ylabel(hAx(2),'cart position [m]') % right y-axis
%set(gcf,'PaperOrientation','landscape');
%print('pendulum_cart_forced','-dpdf'); % pdfcrop is magic

