function [ zsol ] = my_fsolve( funRES, funTAN, z0)
% Basic Newton-solver for nonlinear equation systems
% requires first argument as function returning residuum vector (dim: Nx1) 
% and second argument its tangent matrix (also a function handle)
% third argument is the initial guess

 % options "hard- coded", could be passed via option argument alternatively
  it=0;         % iteration counter
  itmax=250;    % maximal iterations
  TOL=1e-12;    % stopping criteria
  
  z=z0;
  dz=2*TOL;
  while it<itmax && norm(dz, inf)>TOL; 
        it = it+1;
        Res=feval(funRES, z);
        Tan=feval(funTAN, z);
        %dz = -linsolve(Tan, Res);
        dz=-(Tan\Res);
        z = z+dz;
  end

  if it==itmax
      disp('Maximum number of iterations -- bad convergence');
  end

  zsol=z;      
end

endfunction

