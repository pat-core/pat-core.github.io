function [ t, q, v ] = HeavyTopInt ( rinfty, h )
% HeavyTopInt
%
% Benchmark Heavy Top: Time Integration
%
% Parameters
%   rinfty (input)  : damping ratio at infinity \rho_\infty
%   h      (input)  : time step size
%   t      (output) : time grid for output variables
%   q      (output) : position coordinates
%   v      (output) : velocity coordinates
%
% Example
%   [ t, q, v ] = HeavyTopInt ( 0.9, 1.0e-3 );
%   figure ( 1 ),   plot ( t, q(:,[1 5 9]) )
%   figure ( 2 ),   plot ( t, v )
%
% Author :      Martin Arnold (martin.arnold@mathematik.uni-halle.de)
% Version of :  Sep 8, 2016

s = 0.1;

tint = HeavyTopODE ( [], [], 'tint' );

t0 = tint(1);
te = tint(2);

nt = 1 + round ( ( te - t0 ) / h );

t = zeros ( nt, 1 );
q = zeros ( nt, 9 );
v = zeros ( nt, 3 );

n = 0;
tn = t0;

[ qn, vn, vdn, an ] = HeavyTopInit ( rinfty, s, h );

t(1+n) = tn;
q(1+n,:) = [ qn(:,1)' qn(:,2)' qn(:,3)' ]; 
v(1+n,:) = vn';

while tn+h<=te
    
    [ qnp1, vnp1, vdnp1, anp1 ] = HeavyTopCorr ( qn, vn, vdn, an, rinfty, h );
    
    n = n + 1;
    tn = tn + h;
    qn = qnp1;
    vn = vnp1;
    vdn = vdnp1;
    an = anp1;

    t(1+n) = tn;
    q(1+n,:) = [ qn(:,1)' qn(:,2)' qn(:,3)' ]; 
    v(1+n,:) = vn';

end

end