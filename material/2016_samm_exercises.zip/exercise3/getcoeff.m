function [ alpham, alphaf, beta, gamma ] = getcoeff ( rinfty )
% GetCoeff
%
% Get coefficients of generalized-\alpha method
%
% Parameters
%   rinfty (input)  : damping ratio at infinity \rho_\infty
%   alpham (output) : parameter \alpha_m
%   alphaf (output) : parameter \alpha_f
%   beta   (output) : parameter \beta
%   gamma  (output) : parameter \gamma
%
% Author :      Martin Arnold (martin.arnold@mathematik.uni-halle.de)
% Version of :  Sep 8, 2016

% -> define parameters
alpham = ( rinfty - 1 ) / ( rinfty + 1 );
alphaf = rinfty / ( rinfty + 1 );
gamma  = 0.5 + alphaf - alpham;
beta   = ( gamma + 0.5 )^2 / 4;

end         