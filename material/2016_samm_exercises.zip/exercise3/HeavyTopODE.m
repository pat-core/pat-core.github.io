function yout = HeavyTopODE ( R, Omega, job )
% HeavyTopODE
%
% Model data of benchmark problem Heavy Top: ODE formulation
%
% Parameters
%   R      (input)  : r matrix
%   Omega  (input)  : angular velocity
%   job    (input)  : control flag
%                       ='tint'   .. time interval of interest
%                       ='initR'  .. initial value R(t0)
%                       ='initOm' .. initial value Omega(t0)
%                       ='mass'   .. mass matrix
%                       ='force'  .. force vector 
%   yout   (output) : output vector or output matrix
%
% Author :      Martin Arnold (martin.arnold@mathematik.uni-halle.de)
% Version of :  Sep 8, 2016

% -> model data
t0 = 0.0;                                          % initial time
te = 2.0;                                          % end time

R0 = eye(3);                                       % initial value rotation matrix
Omega0 = [ 0 1.5 -0.0461538 ]';                    % initial value angular velocity

m = 15.0;                                          % mass
X = [ 0 1 0 ]';                                    % position of center of mass
Jbar = diag ( [ 15.234375 0.46875 15.234375 ] );   % inertia tensor

ggrav = [ 0.0 0.0 -9.81 ]';                        % gravity vector

% -> output
switch job
    case 'tint'
        yout = [ t0 te ];
    case 'initR'
        yout = R0;
    case 'initOm'
        yout = Omega0;
    case 'mass'
        yout = Jbar;
    case 'force'
        OmTilde = TildOp ( Omega );
        XTilde = TildOp ( X );
        yout = - OmTilde * Jbar * Omega + XTilde * R' * m * ggrav;    
end 

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function OmTilde = TildOp ( Omega )

OmTilde = [ 0 -Omega(3) Omega(2); Omega(3) 0 -Omega(1); -Omega(2) Omega(1) 0 ];

end