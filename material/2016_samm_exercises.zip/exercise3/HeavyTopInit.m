function [ q0, v0, vd0, a0 ] = HeavyTopInit ( rinfty, s, h )
% HeavyTopInit
%
% Starting values for time integration of benchmark problem Heavy Top
% ODE formulation
%
% Parameters
%   rinfty (input)  : damping ratio at infinity \rho_\infty
%   s      (input)  : parameter to define increment in difference approximation
%   h      (input)  : time step size
%   q0     (output) : starting value position coordinates
%   v0     (output) : starting value velocity coordinates
%   vd0    (output) : starting value acceleration coordinates
%   a0     (output) : starting value auxiliary vectors a_n
%
% Author :      Martin Arnold (martin.arnold@mathematik.uni-halle.de)
% Version of :  Sep 8, 2016

% -> read model data: initial values
q0 = HeavyTopODE ( [], [], 'initR' );
v0 = HeavyTopODE ( [], [], 'initOm' );

% -> get acceleration vector from equilibrium conditions
M0 = HeavyTopODE ( q0, v0, 'mass' );
f0 = HeavyTopODE ( q0, v0, 'force' );

vd0 = M0 \ f0;

% -> set a_0 to an approximation of \dot{v}(t_0+\Delta_\alpha h)
qpsh = q0 * ExpSO3 ( s*h*v0 + (s*h)^2/2*vd0 ); 
vpsh = v0 + s*h*vd0; 

Mpsh = HeavyTopODE ( qpsh, vpsh, 'mass' );
fpsh = HeavyTopODE ( qpsh, vpsh, 'force' );

vdpsh = Mpsh \ fpsh;

qmsh = q0 * ExpSO3 ( - s*h*v0 + (s*h)^2/2*vd0 ); 
vmsh = v0 - s*h*vd0; 

Mmsh = HeavyTopODE ( qmsh, vmsh, 'mass' );
fmsh = HeavyTopODE ( qmsh, vmsh, 'force' );

vdmsh = Mmsh \ fmsh;

[ alpham, alphaf, beta, gamma ] = getcoeff ( rinfty );
delal = alpham - alphaf;

a0 = vd0 + delal*h * ( vdpsh - vdmsh ) / ( 2*s*h );

end
