function OmExp = ExpSO3 ( Omega )
% ExpSO3
%
% Evaluate exponential map for Lie group SO(3)
%
% Parameters
%   Omega  (input)  : argument of exponential map ( Omega\in\mathbb{R}^3 )
%   OmExp  (output) : matrix exponential
%
% Author :      Martin Arnold (martin.arnold@mathematik.uni-halle.de)
% Version of :  Sep 8, 2016

% -> evaluate matrix exponential by Rodrigues' formula
OmTilde = [ 0 -Omega(3) Omega(2); Omega(3) 0 -Omega(1); -Omega(2) Omega(1) 0 ];

nrmOm = norm ( Omega );
OmExp = eye(3) + sin(nrmOm)/nrmOm * OmTilde +  ...
          ( 1 - cos(nrmOm) ) / nrmOm^2 * OmTilde * OmTilde;

end