function [ qnp1, vnp1, vdnp1, anp1 ] = HeavyTopCorr ( qn, vn, vdn, an, rinfty, h )
% HeavyTopCorr
%
% Benchmark Heavy Top: Corrector iteration
%
% Parameters
%   qn     (input)  : position coordinates at previous time point t_n
%   vn     (input)  : velocity coordinates at previous time point t_n
%   vdn    (input)  : acceleration coordinates at previous time point t_n
%   an     (input)  : auxiliary vector at previous time point t_n
%   rinfty (input)  : damping ratio at infinity \rho_\infty
%   h      (input)  : time step size
%   qnp1   (output) : position coordinates at previous time point t_{n+1}
%   vnp1   (output) : velocity coordinates at previous time point t_{n+1}
%   vdnp1  (output) : acceleration coordinates at previous time point t_{n+1}
%   anp1   (output) : auxiliary vector at previous time point t_{n+1}
%
% Author :      Martin Arnold (martin.arnold@mathematik.uni-halle.de)
% Version of :  Sep 8, 2016

% -> algorithmic parameters, tolerances etc.
[ alpham, alphaf, beta, gamma ] = getcoeff ( rinfty );

atol = 1.0e-12;
rtol = 1.0e-10;

maxit = 100;

% -> iteration matrix
JNewt = ( 1 - alpham ) / ( beta * ( 1 - alphaf ) ) * HeavyTopODE ( qn, vn, 'mass' );

% -> initial guess
delq = vn + h/2 * an;

it = 0;
err = 0;

% -> simplified Newton
while ( ( (it==0) || (err>1) ) && (it<=maxit) )
    res = h * HeavyTopRes ( delq, qn, vn, vdn, an, rinfty, h );
    pNewt = JNewt \ res;
    err = sqrt ( sum ( (pNewt./(atol+rtol*abs(delq))).^2 ) / 3 );
    it = it + 1;
    delq = delq - pNewt;
end

if err<=1
    qnp1 = qn * ExpSO3 ( h*delq );
    vnp1 = gamma/beta * delq + ( 1 - gamma/beta ) * vn +  ...
             h * ( 1 - gamma / (2*beta) ) * an; 
    vdnp1 = ( 1 - alpham ) / ( beta * ( 1 - alphaf ) ) * ( ( delq - vn ) / h - an/2 )+  ...
              ( an - alphaf*vdn ) / ( 1 - alphaf ); 
    anp1 = ( ( 1 - alphaf ) * vdnp1 + alphaf * vdn - alpham * an ) / ( 1 - alpham );          
else
    qnp1 = NaN;
    vnp1 = NaN;
    vdnp1 = NaN;
    anp1 = NaN;
    error ( 'Newton method failed to converge' )
end

end
