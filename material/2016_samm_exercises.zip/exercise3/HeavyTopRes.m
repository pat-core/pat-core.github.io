function res = HeavyTopRes ( delq, qn, vn, vdn, an, rinfty, h )
% HeavyTopRes
%
% Benchmark problem Heavy Top: Residual in generalized-\alpha time integration
%
% Parameters
%   delq   (input)  : current value of \Delta q_n
%   qn     (input)  : position coordinates at previous time point t_n
%   vn     (input)  : velocity coordinates at previous time point t_n
%   vdn    (input)  : acceleration coordinates at previous time point t_n
%   an     (input)  : auxiliary vector at previous time point t_n
%   rinfty (input)  : damping ratio at infinity \rho_\infty
%   h      (input)  : time step size
%   res    (output) : residual in corrector equations
%
% Author :      Martin Arnold (martin.arnold@mathematik.uni-halle.de)
% Version of :  Sep 8, 2016

% -> get coefficients
[ alpham, alphaf, beta, gamma ] = getcoeff ( rinfty );

% -> get q_{n+1}, v_{n+1}, \dot{v}_{n+1}
qnp1 = qn * ExpSO3 ( h*delq );
vnp1 = gamma/beta * delq + ( 1 - gamma/beta ) * vn +  ...
         h * ( 1 - gamma / (2*beta) ) * an; 
vdnp1 = ( 1 - alpham ) / ( beta * ( 1 - alphaf ) ) * ( ( delq - vn ) / h - an/2 )+  ...
          ( an - alphaf*vdn ) / ( 1 - alphaf ); 

% -> evaluate residual
Mnp1 = HeavyTopODE ( qnp1, vnp1, 'mass' );
fnp1 = HeavyTopODE ( qnp1, vnp1, 'force' );

res = Mnp1 * vdnp1 - fnp1;

end
 