function dzdt = releq( t, z, system )
	% Reduced Euler-Lagrange Equations (mesh-space) 
	% z=[q, v]
	L=system.L;
	R=system.R;
	C=system.C;
	K2=system.K2;
	
	dzdt=zeros(6,1);
	q=z(1:3);
	v=z(4:6);
	
	dzdt(1:3)=z(4:6);
	dzdt(4:6)=(K2'*L*K2)\K2'*(-C*K2*q-R*K2*v);
	
	
	endfunction
	