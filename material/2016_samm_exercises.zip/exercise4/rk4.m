function [t_RK4,x_RK4] = rk4(f,x0,N,tau,system)
% Runge-Kutta 4.order with fixed time step
% f     ... right hand side of ODE
% x0    ... inital values
% N     ... number of time steps
% tau   ... time step
% system... parameters

 x_RK4(:,1)=x0;
 t_RK4(1)=0;
  

 for k=1:N
    
      t_RK4(k+1)=k*tau;
      k1=feval(f,t_RK4(k+1),x_RK4(:,k),system);
      k2=feval(f,t_RK4(k+1)+1/2*tau,x_RK4(:,k)+0.5*tau*k1,system);
      k3=feval(f,t_RK4(k+1)+1/2*tau,x_RK4(:,k)+0.5*tau*k2,system);
      k4=feval(f,t_RK4(k+1)+tau,x_RK4(:,k)+1.0*tau*k3,system);
      sk=k1/6 + k2/3 + k3/3 + k4/6;
      x_RK4(:,k+1)=x_RK4(:,k)+tau*sk;     
      
 end

endfunction
    
    
        
        

   
   
   


    
    
