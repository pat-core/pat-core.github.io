function out = anasol_circuit_R(system)

% system.h: time step
% system.N: number of iterations
% system.nqred: dimension of reduced configuration space (mesh space)
%
% out.qred: charges in reduced (mesh) space
% out.vred: currents in reduced (mesh) space
% out.pred: fluxes in reduced (mesh) space
% out.q: charges in full (branch) space
% out.v: currents in full (branch) space
% out.p: fluxes in full (branch) space
%
% system.K: Kirchhoff Constraint matrix
% system.K2: Fundamental loop matrix

t=0:system.h:(system.N-1)*system.h;



y(1,:) = 0.5e0 .* exp(-0.5000000000e-3 .* t) .* cos(1 .* t) + 2.5000e-04 .* exp(-0.5e-3 .* t) .* sin(1 .* t) ...        
         + 0.5e0 .* exp(-0.1000000000e-2 .* t) .* cos(0.1414213210e1 .* t) ...
         + 0.353553478e-3 .* exp(-0.1000000000e-2 .* t) .* sin(0.1414213210e1 .* t);

y(2,:) =  0.5000000003e0 .* exp(-0.5e-3 .* t) .* cos(1 .* t)...
    + 0.25e-3 .* exp(-0.5e-3 .* t) .* sin(1 .* t) ...
    + 0.5e0 .* exp(-0.1000000000e-2 .* t) .* cos(0.1414213210e1 .* t) ...
    + 0.353553478e-3 .* exp(-0.1000000000e-2 .* t) .* sin(0.1414213210e1 .* t);

y(3,:) =   0.1000000000e1 .* exp(-0.1000000000e-2 .* t) .* cos(0.1414213210e1 .* t) ...
         + 0.707106958e-3 .* exp(-0.1000000000e-2 .* t) .* sin(0.1414213210e1 .* t);

y(4,:) = -0.5e0 .* exp(-0.5000000000e-3 .* t) .* sin(1 .* t)   ...
        - 0.7071069570e0 .* exp(-0.1000000000e-2 .* t) .* sin(0.1414213210e1 .* t);


y(5,:) =   - 0.5000000e0 .* exp(-0.5e-3 .* t) .* sin(1 .* t) ...
          - 0.7071069570e0 .* exp(-0.1000000000e-2 .* t) .* sin(0.1414213210e1 .* t);

y(6,:) =     - 0.1414213915e1 .* exp(-0.1000000000e-2 .* t) .* sin(0.1414213210e1 .* t);

out.qred = y(1:system.nqred,:);
out.vred = y(system.nqred+1:2.*system.nqred,:);
for i=1:size(y(:,2))
    out.pred(:,i) = system.KLK * out.vred(:,i);
end
out.p(:,1)=system.L*system.v0;

% full variables out of reduced variables
for i=1:system.N
    out.q(:,i) = system.K2*out.qred(:,i);
    out.v(:,i) = system.K2*out.vred(:,i);
    out.p(:,i) = system.L*out.v(:,i);
end

for i=1:system.N
    out.constr(:,i) =  system.K'*out.v(:,i);
end

endfunction


