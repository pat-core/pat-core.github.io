% SAMM2016 excercise 4, simulations of RLC-networks by a VIs derived
% from the Lagrange-D'Alembert-Pontryagin principle
% here assuming linear elements
clc;
clear;
close all;

%% init
h=0.4;   % 0.1; 0.4;
t=0:h:700;  % 30; 700; 2000;
N=length(t);
R1=0.001; % 0; 0.001;

% Kirchhoff Constraint Matrix
KK=[	1,-1,0;...
 	0, -1,1;...
 	0,0,1;...
 	-1,0,0;...
 	0,-1,0;...
 	1,0,-1];

% Fundamental Loop Matrix
K2=	[1,0,-1;...
	0,-1,1;...
	0,1,0;...
	1,0,0;...
	-1,1,0;...
	0,0,1];

% branch space
L=diag([1,1,1,1,1,0]);
R=diag([1,1,1,1,1,1])*R1;
C=diag([1,1,1,1,1,1]);

% mesh space
Lm=K2'*L*K2;
Cm=K2'*C*K2;
Rm=K2'*R*K2;


%% VI Euler forward
A1=[	eye(3), zeros(3), zeros(3);...
	zeros(3), Lm, -eye(3);...
	h*Cm, h*Rm, eye(3)];

B1=[	eye(3), h*eye(3), zeros(3);...
	zeros(3),zeros(3),zeros(3);...
	zeros(3), zeros(3), eye(3)];


%% VI Euler backward
A2=[	eye(3), -h*eye(3), zeros(3);...
	zeros(3), Lm, -eye(3);...
	zeros(3), zeros(3), eye(3)];
	
B2=[	eye(3), zeros(3), zeros(3);...
	zeros(3), zeros(3), zeros(3);...
	-h*Cm, -h*Rm, eye(3)];
	
%% VI mid-point rule
A3=[	eye(3), -h*eye(3), zeros(3);...
zeros(3), Lm, -1/2*eye(3);...
1/2*h*Cm, h*Rm, eye(3)];

B3=[ 	eye(3), zeros(3), zeros(3);...
	zeros(3), zeros(3), 1/2*eye(3);...
	-1/2*h*Cm, zeros(3), eye(3)];

%% VI loop (mesh-space)
q0=[1;1;1];
v0=[0;0;0];
p0=Lm*v0;
q1=zeros(N,3);
v1=zeros(N,3);
p1=zeros(N,3);
q2=zeros(N,3);
v2=zeros(N,3);
p2=zeros(N,3);
q3=zeros(N,3);
v3=zeros(N,3);
p3=zeros(N,3);
q1(1,:)=q0;
v1(1,:)=v0;
p1(1,:)=p0;
q2(1,:)=q0;
v2(1,:)=v0;
p2(1,:)=p0;
q3(1,:)=q0;
v3(1,:)=v0;
p3(1,:)=p0;

for k=1:N-1  % N-1 time steps to reach N. time point
    % VI Euler forward
	zk=[q1(k,:), v1(k,:), p1(k,:)]';
	zkp1= A1\B1*zk;
	q1(k+1,:)=zkp1(1:3);
	v1(k+1,:)=zkp1(4:6);
	p1(k+1,:)=zkp1(7:9);
	
    % VI Euler backward
	zk=[q2(k,:), v2(k,:), p2(k,:)]';
	zkp1= A2\B2*zk;
	q2(k+1,:)=zkp1(1:3);
	v2(k+1,:)=zkp1(4:6);
	p2(k+1,:)=zkp1(7:9);
	
    % VI mid-point
	zk=[q3(k,:), v3(k,:), p3(k,:)]';
	zkp1= A3\B3*zk;
	q3(k+1,:)=zkp1(1:3);
	v3(k+1,:)=zkp1(4:6);  % v at t_{k-1/2}
	p3(k+1,:)=zkp1(7:9);
end

% convert to branch space    
Q1=(K2*q1')';
Q2=(K2*q2')';
Q3=(K2*q3')';
V1=(K2*v1')';
V2=(K2*v2')';  % t=-h/2...(N-1/2)h
V3=(K2*v3')';
P1=(K2*p1')';
P2=(K2*p2')';
P3=(K2*p3')';

tc=[t(1:end-1)/2+t(2:end)/2, t(end)+h/2] - h;  % t=-h/2...(N-h/2) for plots of currents obtained by VI mp

%% runge kutta 4, fixed step size for comparison
Q0=K2*q0;   % initial conditions in branch space
V0=K2*v0;   
system.h=h; % store system description in one structured variable
system.N=N;
system.nqred=3;
system.K=KK;
system.K2=K2;
system.KLK=Lm;
system.L=L;
system.R=R;
system.C=C;
system.v0=V0;
system.q0=Q0;

[t4, qv4] = rk4(@releq, [q0; v0], N-1, h, system);
q4=qv4(1:3,:)';
v4=qv4(4:6,:)';
Q4=(K2*q4')';
V4=(K2*v4')';


%% analytical solution
if R1==0
    Sa=anasol_circuit(system);   % without R, only LC
    
else
    Sa=anasol_circuit_R(system); % RLC
end

%% post-processing
energya=zeros(N,1);
energy1=zeros(N,1);
energy2=zeros(N,1);
energy3=zeros(N,1);
energy4=zeros(N,1);
for k=1:N 
    energya(k)=1/2*Sa.v(:,k)'*L* Sa.v(:,k) + 1/2*Sa.q(:,k)'*C* Sa.q(:,k);
    energy1(k)=1/2*p1(k,:)*(Lm\p1(k,:)')   + 1/2*q1(k,:) *Cm* q1(k,:)';  % use primary variables q and p 
    energy2(k)=1/2*p2(k,:)*(Lm\p2(k,:)')   + 1/2*q2(k,:) *Cm* q2(k,:)';   
    energy3(k)=1/2*p3(k,:)*(Lm\p3(k,:)')   + 1/2*q3(k,:) *Cm* q3(k,:)';   
    energy4(k)=1/2*v4(k,:)*Lm*v4(k,:)'    + 1/2*q4(k,:) *Cm* q4(k,:)'; % in this formulation q and v available  
end


figure;
plot(t,Sa.v(1,:), t,V1(:,1), t,V2(:,1), tc,V3(:,1), t4, V4(:,1)); 
xlabel('time'); ylabel('current on branch 1');
legend('exact','VI EFD','VI EBD','VI mp','RK4');

figure;
plot(t,energya, t,energy1, t,energy2, t,energy3, t4,energy4);
xlabel('time'); ylabel('total energy');
legend('exact','VI EFD','VI EBD','VI mp','RK4');
