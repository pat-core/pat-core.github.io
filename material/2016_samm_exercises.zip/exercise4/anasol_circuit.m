function out = anasol_circuit(system)

% system.h: time step
% system.N: number of iterations
% system.nqred: dimension of reduced configuration space (mesh space)

% out.qred: charges in reduced (mesh) space
% out.vred: currents in reduced (mesh) space
% out.pred: fluxes in reduced (mesh) space
% out.q: charges in full (branch) space
% out.v: currents in full (branch) space
% out.p: fluxes in full (branch) space

% system.K: Kirchhoff Constraint matrix
% system.K2: Fundamental loop matrix
% system.KLK:
% system.L:
% system.v0:

t=0:system.h:(system.N-1)*system.h;


y(1,:) = cos(t) / 0.2e1 + cos(sqrt(0.2e1) * t) / 0.2e1;
y(2,:) = cos(t) / 0.2e1 + cos(sqrt(0.2e1) * t) / 0.2e1;
y(3,:) = cos(sqrt(0.2e1) * t);
y(4,:) = -sin(sqrt(0.2e1) * t) * sqrt(0.2e1) / 0.2e1 - sin(t) / 0.2e1;
y(5,:) = -sin(sqrt(0.2e1) * t) * sqrt(0.2e1) / 0.2e1 - sin(t) / 0.2e1;
y(6,:) = -sin(sqrt(0.2e1) * t) * sqrt(0.2e1);

out.qred = y(1:system.nqred,:);
out.vred = y(system.nqred+1:2*system.nqred,:);
for i=1:size(y,2)
    out.pred(:,i) = system.KLK * out.vred(:,i);
end
out.p(:,1)=system.L*system.v0;

% full variables out of reduced variables
for i=1:system.N
    out.q(:,i) = system.K2*out.qred(:,i);
    out.v(:,i) = system.K2*out.vred(:,i);
    out.p(:,i) = system.L*out.v(:,i);
end

for i=1:system.N
    out.constr(:,i) =  system.K'*out.v(:,i);
end

endfunction

