% SAMM 2017, exercise 1b: sim. of a pendulum on a cart with holonomic-rheonomic
% constraint by a Variational Integrator (linear interpolation, m.p.-rule)
% enforcing constraint on position-, but not on velocity-level
%
% author: dominik.kern@mb.tu-chemnitz.de
%
% q=[a, x] pendulum angle a, cart position x
%
% future work
%   1)  include constraint force into variational principle in order to obtain
%       physically meaningful Lagrange-multiplier (cart force in this example)
%   2)  implement enforcement of constraint on velocity-level too and
%       compare with results obtained by constraint on pos.-level only
%   3)  check if scaling of the constraint equations by time step h allows
%       to reduce the Newton-Tol, as the cond. number (lin.sys.) decreases
clear; close all; clc;
format long g

%% INIT
% model parameters
mp=1;       % pendulum mass (mathematical pendulum)
mc=0.5;     % cart mass
l=0.1;      % pendulum length (mathematical pendulum)
g=9.81;     % gravitational acceleration
a0=-pi/2;   % initial pendulum angle
at0=0;      % initial angular velocity
xh=l/5;     % forcing amplitude (displacement)
T=2*pi/sqrt(g/l);   % period of pendulum only (without cart), for estimating time step and forcing
% dependent parameters
m=mp+mc;    % total mass
J=mp*l^2;   % pendulum, moment of inertia
te=4*T;   % end time

% prescribed cart displacement and its time derivatives
xc=@(tt) xh*sin(2*pi*tt/T);
xct=@(tt) xh*cos(2*pi*tt/T)*(2*pi/T);
xctt=@(tt) -xh*sin(2*pi*tt/T)*(2*pi/T)^2;

% time discretization
h=T/200;
t=0:h:te;
N=length(t)-1;

% Da=a2-a1, Dx=x2-x1, Sa=a2+a1, Sx=x2+x1 for brevity, although this obscures the arguments of Ld([a1,x1],[a2,x2])
D1Ld=@(Da,Dx,Sa,Sx) [ mp*l*Dx*(sin(Sa/2)-(Da/2)*cos(Sa/2)) - J*Da - (h^2/2)*mp*g*l*cos(Sa/2);...
                     -m*Dx + mp*l*Da*sin(Sa/2)  ]/h;
D2Ld=@(Da,Dx,Sa,Sx) [-mp*l*Dx*(sin(Sa/2)+(Da/2)*cos(Sa/2)) + J*Da - (h^2/2)*mp*g*l*cos(Sa/2);...
                      m*Dx - mp*l*Da*sin(Sa/2) ]/h;
D2D1Ld=@(Da,Dx,Sa,Sx) [ mp*l*Dx*(Da/4)*sin(Sa/2) - J+(h^2/4)*mp*g*l*sin(Sa/2),...
                        mp*l*(sin(Sa/2)-(Da/2)*cos(Sa/2));...
                        mp*l*(sin(Sa/2)+(Da/2)*cos(Sa/2)),...
                       -m ]/h;
phi=@(t,a,x)     ( x-xc(t) );     % holonomic-rheonomic constraint..              
Dphi=@(a,x)       [0; 1];      % ..and its gradient
        
% iteration equation at time t1 and pos./mom. at begin of time step q1,p1, unknown un=[q2(1), q2(2), lam] and its tangent
ieqRES=@(T1,P1,Q1,UN) [P1 + D1Ld(UN(1)-Q1(1),UN(2)-Q1(2),UN(1)+Q1(1),UN(2)+Q1(2)) - h*UN(3)*Dphi(Q1(1),Q1(2)); phi(T1+h,UN(1),UN(2))]; 
ieqTAN=@(T1,P1,Q1,UN) [D2D1Ld(UN(1)-Q1(1),UN(2)-Q1(2),UN(1)+Q1(1),UN(2)+Q1(2)), -h*Dphi(Q1(1),Q1(2));...
                       Dphi(UN(1),UN(2)).', 0];

% conversion generalized velocities to momenta and back 
v2p=@(AA,XX,AT,XT) [J, -mp*l*sin(AA); -mp*l*sin(AA), m]*[AT; XT];
p2v=@(AA,XX,PA,PX) [J, -mp*l*sin(AA); -mp*l*sin(AA), m]\[PA; PX];

% result vectors for N time steps, i.e. at N+1 time points
q=zeros(N+1,2);   % generalized coordinates
p=zeros(N+1,2);	  % generalized momenta
v=zeros(N+1,2);	  % generalized velocities
lam=zeros(N,1);	  % Lagrange multiplier=constraint force, N instead N+1, as last value not evaluated


%% VI
q1=[a0; xc(0)];     % initial positions
p1=v2p(a0,xc(0),at0,xct(0));    % initial momenta
q(1,:)=q1;
p(1,:)=p1;
v(1,:)=[at0, xct(0)];       % initial velocities
unp=[q1+h*[at0; xct(0)]; 0]; % prediction for q2 and Lagrange multiplier
cviolation=zeros(N,2);     % violation of constraints

for n=1:N    % time step t_1=(n-1)*h ... t2=n*h
    un=my_fsolve(@(uu) ieqRES(t(n),p1,q1,uu),...
                 @(uu) ieqTAN(t(n),p1,q1,uu),...
                 unp) ; % solving for unknowns q2 and lambda with initial guess unp
    q2=un(1:2);        % positions at end of time step  
    lam(n)=un(3);      % Lagrange multiplier at begin of time step
    p2=D2Ld(q2(1)-q1(1), q2(2)-q1(2), q2(1)+q1(1), q2(2)+q1(2)); % update equation 
    q(n+1,:)=q2;
    p(n+1,:)=p2;
    v(n+1,:)=p2v(q2(1), q2(2), p2(1), p2(2));   % store velocities for postprocessing
    unp=[2*q2-q1; lam(n)]; % prediction for next iteration 
    cviolation(n,1)= q(n+1,2) - xc(t(n+1));     % constraint violation pos.-,
    cviolation(n,2)= v(n+1,:) * Dphi(q2(1), q2(2)) - xct(t(n+1)); %...vel.-level
    q1=q2;
    p1=p2;
end


%% post-processing

disp(['a(t_e)=',num2str(q(end,1)),' RAD      lambda(t_e)=',num2str(lam(end)),' m']);

figure;  %figure_init;
[hAx,hLine1,hLine2]=plotyy(t, q(:,1), t(1:end-1), lam);
%set(hAx(1),'PlotBoxAspectRatio' , [1 1 0.9]);
%set(hAx(2),'PlotBoxAspectRatio' , [1 1 0.9]);
xlabel('time [s]')
ylabel(hAx(1),'pendulum angle [RAD]') % left y-axis
ylabel(hAx(2),'constraint force [N]') % right y-axis
%set(gcf,'PaperOrientation','landscape');
%print('pendulum_cart_constrained','-dpdf');

figure;  
[hAx,hLine1,hLine2]=plotyy(t(1:end-1), cviolation(:,1)/xh, t(1:end-1), cviolation(:,2)/(xh*2*pi/T));
xlabel('time [s]')
ylabel(hAx(1),'constraint on position-level') % left y-axis
ylabel(hAx(2),'constraint on velocity-level') % right y-axis


figure;
tc=t(1:end-1)/2+t(2:end)/2;
plot(t,xct(t), t,v(:,2), tc,diff(q(:,2))/h );
xlabel('t'); ylabel('v_x'); legend('xct','v','Dx/h');


