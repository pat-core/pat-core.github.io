#include "hello.hxx"
#include "world.hxx"

int main()
{
	hello first_word;
	world second_word;

	first_word.print();
	second_word.print();
	return 0;
}
