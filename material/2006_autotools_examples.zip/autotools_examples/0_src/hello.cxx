#include "hello.hxx"

void hello::print(){
    std::cout<<" Hello ";
}
