#include <iostream>
#ifndef HELLO_HXX
#define HELLO_HXX

class hello{
public:
	void print();
};
#endif



