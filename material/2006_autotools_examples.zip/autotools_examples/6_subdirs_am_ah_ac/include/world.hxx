#include <iostream>
#ifndef WORLD_HXX
#define WORLD_HXX

class world{
public:
	void print();
};
#endif



