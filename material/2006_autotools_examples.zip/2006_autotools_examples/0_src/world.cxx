#include "world.hxx"

void world::print(){
    std::cout<<" World \n";
}
