'''
Example of a Paraview animation via Python,
tested with Paraview 5.8.1 and Python 3.7.4.
Run "pypython example_animation.py" from the command line.
Check the environment from the python shell within the Paraview GUI for the use as macro.
From this python shell further inspections are possible, 
e.g. of Paraview classes (view, scene, ...).
Useful commands, e.g. load a results file, 
can be discovered from "Tools--start/stop trace in the menubar.

This animation shows a sphere orbiting around another sphere.
'''
from paraview.simple import *	# for paraview
import math	# for sine and cosine

# This cue contains the python code to be run during the animation.
# At start the text and the line are created and at
# each tick they are modified.
PythonAnimationCue1 = PythonAnimationCue()
PythonAnimationCue1.Script= """
def start_cue(self): pass
def tick(self): 
    animationScene1 = GetAnimationScene()
    t = animationScene1.TimeKeeper.Time
    #Planet = FindSource("Planet")
    Planet.Center = [r*math.cos(w*t), r*math.sin(w*t), 0.0]
def end_cue(self): pass
"""


# creation of solar system
r=2.5	# radius of planetary orbit
w=2*3.14159 	# radian frequency of orbiting

renderView1 = GetActiveViewOrCreate('RenderView')
Sun=Sphere()
Sun.ThetaResolution = 20
Sun.PhiResolution = 20
Show()

Planet = Sphere()
Planet.Center = [r, 0.0, 0.0]
Planet.Radius = 0.1
Planet.ThetaResolution = 20
Planet.PhiResolution = 20
Show()

#renderView1.ResetCamera()
renderView1.CameraPosition = [10.0, 0.0, 10.0]	# Where is the camera..
renderView1.CameraFocalPoint = [0.0, 0.0, 0.0]  # ..and where it looks to.
renderView1.CameraViewUp = [0.0, 0.0, 1.0 ] 	# z-axis points up
renderView1.CameraParallelScale = 1

# animation of planet
scene = GetAnimationScene()
scene.Cues.append(PythonAnimationCue1) 

scene.StartTime=0	# simulation time
scene.EndTime=2.0
scene.NumberOfFrames = 100
scene.PlayMode = 'Real Time'
scene.Duration = 4 	# watch time

scene.Play()

